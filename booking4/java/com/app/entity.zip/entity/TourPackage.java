package com.app.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "tour_package")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
//@ToString(exclude = "hotel")

public class TourPackage {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long packageId;

	@Column(length = 30, nullable = false)
	private String packageName;

	private String image;

	private String packageDescription;

	private Integer noOfDays;

//@JsonBackReference
	@JsonIgnore
	@OneToMany
	private List<City> city = new ArrayList<City>();

}
